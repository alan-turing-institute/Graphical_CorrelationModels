
/* cgeneric_corgraphs.c
 *
 * Copyright (C) 2023 Elias Krainski
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * The author's contact information:
 *
 *        Elias Krainski
 *        CEMSE Division
 *        King Abdullah University of Science and Technology
 *        Thuwal 23955-6900, Saudi Arabia
 */

#include "cgeneric_defs.h"

double *inla_cgeneric_corgraphs_sch(inla_cgeneric_cmd_tp cmd, double *theta, inla_cgeneric_data_tp * data)
{

  double *ret = NULL;
  int i, j, k, N, M, np, nparam;

  // the size of the model
  assert(data->n_ints > 1);
  assert(!strcasecmp(data->ints[0]->name, "n"));	       // this will always be the case
  N = data->ints[0]->ints[0];
  assert(N > 0);
  int N2 = N*N;
  M = (int)((double)N * ((double)(N+1)) / 2.0);
  double q2[N], vch[N];

  assert(!strcasecmp(data->ints[1]->name, "debug"));	       // this will always be the case
  int debug = data->ints[1]->ints[0];

  assert(!strcasecmp(data->ints[2]->name, "np"));     // this will always be the case
  np = data->ints[2]->ints[0];
  assert(np > 0);
  nparam = N + np;
  double v2[np], vparents[np];

  assert(!strcasecmp(data->ints[3]->name, "nv"));     // this will always be the case
  inla_cgeneric_vec_tp *nv = data->ints[3];
  assert(nv->len == np);

  assert(!strcasecmp(data->ints[4]->name, "ipar"));     // this will always be the case
  inla_cgeneric_vec_tp *ipar = data->ints[4];
  assert(ipar->len == N);

  assert(!strcasecmp(data->ints[5]->name, "iiv"));     // this will always be the case
  inla_cgeneric_vec_tp *iiv = data->ints[5];

  assert(!strcasecmp(data->ints[6]->name, "jjv"));     // this will always be the case
  inla_cgeneric_vec_tp *jjv = data->ints[6];
  assert(iiv->len == jjv->len);

  assert(!strcasecmp(data->ints[7]->name, "itop"));     // this will always be the case
  inla_cgeneric_vec_tp *itop = data->ints[7];

  assert(!strcasecmp(data->ints[8]->name, "ii"));     // this will always be the case
  inla_cgeneric_vec_tp *ii = data->ints[8];

  assert(!strcasecmp(data->ints[9]->name, "jj"));     // this will always be the case
  inla_cgeneric_vec_tp *jj = data->ints[9];

  assert(!strcasecmp(data->ints[10]->name, "iprior"));     // this will always be the case
  int iprior = data->ints[10]->ints[0];
  assert(iprior>0);

  assert(!strcasecmp(data->doubles[0]->name, "lambda"));
  double lambda = data->doubles[0]->doubles[0];
  assert(lambda>0);

  assert(!strcasecmp(data->doubles[1]->name, "slambdas"));
  inla_cgeneric_vec_tp *slambdas = data->doubles[1];
  assert(slambdas->len>0);
  assert(slambdas->len == N);

  int iprint = 0;
  if((debug>9) & (iprint<1)) {
    iprint++;
    printf("(N = %d, M = %d, np = %d)\n", N, M, np) ;
    printf(" nv:\n");
    for(i=0; i<nv->len; i++) {
      printf("%d ", nv->ints[i]);
    }
    printf("\n iiv:\n");
    for(i=0; i<iiv->len; i++) {
      printf("%d ", iiv->ints[i]);
    }
    printf("\n jjv:\n");
    for(i=0; i<jjv->len; i++) {
      printf("%d ", jjv->ints[i]);
    }
    printf("\n itop[i,j]:\n");
    k=0;
    for(i=0; i<N; i++) {
      for(j=0; j<N; j++) {
        printf("%d ", itop->ints[k]);
        k++;
      }
      printf("\n");
    }
  }

  int q2warning = 0;
  double ssmall = 0.00001;
  if(theta) {
    for(i=0; i<np; i++) {
      v2[i] = exp(2.0 * theta[N+i]);
      vparents[0] = 0.0;
    }
    for(i=0; i<iiv->len; i++) {
      vparents[iiv->ints[i]] += v2[jjv->ints[i]];
    }
    for(i=0; i<N; i++) {
      q2[i] = pow2(theta[i]);
      if(q2[i]<ssmall) {
        q2[i] += (ssmall/10.0); // this goes for the diag
        q2warning++;
      }
    }
    for(i=0; i<N; i++) {
      vch[i] = vparents[ipar->ints[i]] * q2[i] + 1/q2[i];
    }
    if(q2warning>0){
      printf("q2 WARNING:  %2d \n", q2warning);
    }
  } else {
    for(i=0; i<N; i++) {
      q2[i] = NAN;
      vch[i] = NAN;
    }
    for(i=0; i<np; i++) {
      v2[i] = NAN;
      vparents[i] = NAN;
    }
  }

  if(debug>999) {
    printf("q2 and vch:\n");
    for(i=0; i<N; i++) {
      printf("%2.2f %2.2f\n", q2[i], vch[i]);
    }
    printf("v2 and vparents:\n");
    for(i=0; i<np; i++) {
      printf("%2.2f,  %2.2f \n", v2[i], vparents[i]);
    }
  }

  switch (cmd) {
  case INLA_CGENERIC_GRAPH:
  {
    k = 2;
    ret = Calloc(k + 2 * M, double);
    ret[0] = N;                                    /* dimension */
      ret[1] = M;                                    /* number of (i <= j) */
      for (i = 0; i < M; i++) {
        assert(ii->ints[i] <= jj->ints[i]);
        ret[k++] = ii->ints[i];
      }
      for (i = 0; i < M; i++) {
        ret[k] = jj->ints[i];
        /*      if(debug>1){
         printf("%d %2.1f %2.1f\n", i, ret[k-M], ret[k]);
        }*/
        k++;
      }

  }
    break;
  case INLA_CGENERIC_Q:
  {
    int offset = 2, info;
    char uplo = 'U';
    double cc[N2], qq[N2];

    ret = Calloc(offset + M, double);
    //		memset(ret + offset, 0, M * sizeof(double));
    ret[0] = -1;				       /* REQUIRED */
    ret[1] = M;				       /* REQUIRED */

    k=0;
    for(i=0; i<N; i++) {
      for(j=0; j<N; j++) {
        if(j==i) {
          qq[k] = 1.0;
          cc[k] = vparents[ipar->ints[i]] * q2[i] + 1/q2[i];
        } else {
          qq[k] = 0.0;
          cc[k] = theta[i] * vparents[itop->ints[k]] * theta[j];
        }
        k++;
      }
    }

    if(debug>999) {
      printf("V[i,j]:\n");
      k=0;
      for(i=0; i<N; i++) {
        for(j=0; j<N; j++) {
          printf("%2.3f ", cc[k]);
          k++;
        }
        printf("\n");
      }
      printf("Q[i,j]:\n");
      k=0;
      for(i=0; i<N; i++) {
        for(j=0; j<N; j++) {
          printf("%2.3f ", qq[k]);
          k++;
        }
        printf("\n");
      }
    }

    dposv_(&uplo, &N, &N, &cc[0], &N, &qq[0], &N, &info, F_ONE);
    if(debug>999) {
      printf("INFO for dposv for Q is %d\n", info);
    }

    // copy qq to ret;
    int k2 = offset;
    k=0;
    for(i=0; i<N; i++) {
      for(j=0; j<N; j++) {
        if(j>=i){
          ret[k2] = qq[k];
          k2++;
        }
        k++;
      }
    }

  }
    break;
  case INLA_CGENERIC_MU:
  {
    // return (N, mu). if N==0 then mu is not needed as its taken to be mu[]==0
    ret = Calloc(1, double);
    ret[0] = 0;
  }
    break;

  case INLA_CGENERIC_INITIAL:
  {
    // return c(P, initials)
    // where P is the number of hyperparameters
    ret = Calloc(nparam + 1, double);
    ret[0] = nparam;
    for(i = 0; i < N; i++) {
      if((i%2)==0) {
        ret[1+i] = -1.0;
      } else {
        ret[1+i] = 1.0;
      }
    }
    for(i = 0; i < np; i++) {
      ret[1+N+i] = 0.0;
    }
  }
    break;

  case INLA_CGENERIC_LOG_PRIOR:
  {
    ret = Calloc(1, double);
    ret[0] = 0.0;

    // temporary: N(0, 1/lambda_i) for (1/q_i^2 + q_i^2 * v^2)
    double lam;
    for(i = 0; i < N; i++) {
      lam = slambdas->doubles[i];
      ret[0] += -0.5 * pow2(vch[i]) * lam;
    //  ret[0] += log(lam*0.5) -lam * exp(-0.5*vch[i]) -1.5*vch[i];
    }

    if(iprior==1) {

      // this is Gaussian(0, lambda) for each log(v_j^2)
      for(i = 0; i < np; i++) {
        ret[0] += -0.5 * pow2(theta[N+i]) / lambda;
      }

    }

    if (iprior == 2 ) {
      // this is the PC-prior for v_j^2
      for(i=0; i<np; i++) {
        ret[0] += log(lambda) -lambda * exp(theta[N+i]) + theta[N+i];
      }

    }

    if(iprior == 3) {

      char uplo = 'U';
      int info=0, l;
      double hldet0, hldet1, trc, kld;
      double v2a[np], v2b[np], vp0[np], vp1[np];
      double s0[N], s1[N];
      double C0[N2], C1[N2], cc0[N2], cc1[N2];

      for(i=0; i<np; i++) {
        v2a[i] = v2[i]; // copy
        v2b[i] = v2[i]; // copy
      }

      for(l=np; l>0; l--) {

        if(debug>999) {
          printf("l is now %d\n", l);
        }

        v2a[l-1] = 0.0;
        if(l<np) {
          v2b[l]= 0.0;
        }

        if(debug>999){
          printf("v2a[i]:\n");
          for(i=0; i<np; i++) {
            printf("%2.1f ", v2a[i]);
          }
          printf("\n");
          printf("v2b[i]:\n");
          for(i=0; i<np; i++) {
            printf("%2.1f ", v2b[i]);
          }
          printf("\n");
        }

        for(i=0; i<np; i++) {
          vp0[i] = 0.0;
          vp1[i] = 0.0;
        }
        for(i=0; i<iiv->len; i++) {
          vp0[iiv->ints[i]] += v2a[jjv->ints[i]];
          vp1[iiv->ints[i]] += v2b[jjv->ints[i]];
        }

        k=0;
        for(i=0; i<N; i++) {
          for(j=0; j<N; j++) {
            if(j==i) {
              C0[k] = vp0[ipar->ints[i]] * q2[i] + 1/q2[i];
              C1[k] = vp1[ipar->ints[i]] * q2[i] + 1/q2[i];
              s0[i] = sqrt(C0[k]);
              s1[i] = sqrt(C1[k]);
            } else {
              C0[k] = theta[i] * vp0[itop->ints[k]] * theta[j];
              C1[k] = theta[i] * vp1[itop->ints[k]] * theta[j];
            }
            k++;
          }
        }

        if(debug>999){
          printf("vp0[i]:\n");
          for(i=0; i<np; i++) {
            printf("%2.1f ", vp0[i]);
          }
          printf("\nvp1[i]:\n");
          for(i=0; i<np; i++) {
            printf("%2.1f ", vp1[i]);
          }
          printf("\ns0[i]:\n");
          for(i=0; i<N; i++) {
            printf("%2.1f ", s0[i]);
          }
          printf("\ns1[i]:\n");
          for(i=0; i<N; i++) {
            printf("%2.1f ", s1[i]);
          }
          printf("\nC0[i,j]:\n");
          k=0;
          for(i=0; i<N; i++) {
            for(j=0; j<N; j++) {
              printf("%2.3f ", C0[k]);
              k++;
            }
            printf("\n");
          }
          printf("C1[i,j]:\n");
          k=0;
          for(i=0; i<N; i++) {
            for(j=0; j<N; j++) {
              printf("%2.3f ", C1[k]);
              k++;
            }
            printf("\n");
          }
        }

        k=0;
        for(i=0; i<N; i++) {
          for(j=0; j<N; j++) {
            C0[k] /= (s0[i] * s0[j]);
            C1[k] /= (s1[i] * s1[j]);
            cc0[k] = C0[k]; // copy
            cc1[k] = C1[k]; // copy
            k++;
          }
        }

        if(debug>999){
          printf("C0[i,j]:\n");
          k=0;
          for(i=0; i<N; i++) {
            for(j=0; j<N; j++) {
              printf("%2.3f ", C0[k]);
              k++;
            }
            printf("\n");
          }
          printf("C1[i,j]:\n");
          k=0;
          for(i=0; i<N; i++) {
            for(j=0; j<N; j++) {
              printf("%2.3f ", C1[k]);
              k++;
            }
            printf("\n");
          }
        }

        dpotrf_(&uplo, &N, &cc0[0], &N, &info, F_ONE);
        if(debug>99) {
          printf("INFO for L0 with l = %d is %d\n", l, info);
        }
        dpotrf_(&uplo, &N, &cc1[0], &N, &info, F_ONE);
        if(debug>99) {
          printf("INFO for L1 with l = %d is %d\n", l, info);
        }

        if(debug>999){
          printf("L0[i,j]:\n");
          k=0;
          for(i=0; i<N; i++) {
            for(j=0; j<N; j++) {
              printf("%2.3f ", C0[k]);
              k++;
            }
            if(debug>1){
              printf("\n");
            }
          }
          printf("L1[i,j]:\n");
          k=0;
          for(i=0; i<N; i++) {
            for(j=0; j<N; j++) {
              printf("%2.3f ", C1[k]);
              k++;
            }
            if(debug>1){
              printf("\n");
            }
          }
        }

        hldet0 = 0.0;
        hldet1 = 0.0;
        k=0;
        for(i=0; i<N; i++) {
          hldet0 += log(cc0[k]);
          hldet1 += log(cc1[k]);
          if(debug>999){
            printf("ld0 = %2.5f, ld1 = %2.5f\n", cc0[k], cc1[k]);
          }
          k += N+1;
        }

        dposv_(&uplo, &N, &N, &C1[0], &N, &C0[0], &N, &info, F_ONE);
        if(debug>999) {
          printf("INFO for dposv with l = %d is %d\n", l, info);
        }

        // add trace of C1/C0
        k=0;
        for(i=0; i<N; i++) {
          trc += C0[k];
          k += N+1;
        }

        kld = 0.5 * (trc - np) - hldet1 + hldet0;

        if(debug>99) {
          printf("ld0: %2.4f, ld1: %2.4f, tr(C1/C0): %2.4f, kld:= %2.4f\n",
                 hldet0, hldet1, trc, kld);
        }

        ret[0] += log(lambda) - lambda * sqrt(2 * kld);

      }

    }


  }
    break;

  case INLA_CGENERIC_VOID:
  case INLA_CGENERIC_LOG_NORM_CONST:
  case INLA_CGENERIC_QUIT:
  default:
    break;
  }

  return (ret);
}
